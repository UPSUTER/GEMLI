quantify_clusters_iterative <- function(data_matrix, marker_genes, N = 2) {
    iterate <- TRUE
    i <- 2
    corr_expr_raw <- calculate_correlations(data_matrix[marker_genes, , drop=F])
    cell_clusters <- Matrix(0, nrow = ncol(data_matrix), ncol = 1, sparse = TRUE)
    rownames(cell_clusters) <- colnames(data_matrix)
    cell_clusters[, 1] <- rep(1, ncol(data_matrix))

    while (iterate) {
        cell_clusters <- cbind(cell_clusters, Matrix(0, nrow = nrow(cell_clusters), sparse = TRUE))
        unique_clusters <- setdiff(unique(cell_clusters[, (i - 1)]), 0)
        for (cluster in unique_clusters) {
            cluster_indices <- which(cell_clusters[, (i - 1)] == cluster)
            cells_in_cluster <- rownames(cell_clusters)[cluster_indices]

            if (length(cells_in_cluster) >= 4) {
                corr_expr_subset <- (1 - corr_expr_raw[cells_in_cluster, cells_in_cluster]) / 2
                clustering <- cutree(hclust(as.dist(corr_expr_subset), method = "ward.D2"), k = N)
                cell_clusters[cluster_indices, i] <- as.vector(clustering) + max(c(0, cell_clusters[, i]), na.rm = TRUE)
            } else {
                cell_clusters[cluster_indices, i] <- 0
            }
        }

        if (sum(cell_clusters[, i], na.rm = TRUE) == 0) {
            iterate <- FALSE
        }
        i <- i + 1
    }

    cell_clusters[cell_clusters == 0] <- NA
    return(cell_clusters)
}
