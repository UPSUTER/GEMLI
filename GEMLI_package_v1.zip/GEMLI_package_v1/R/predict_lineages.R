predict_lineages <- function(GEMLI_items, repetitions=100, sample_size=(2/3), desired_cluster_size=c(2,3),
                             workers=NULL) {
    if (class(GEMLI_items)=='list') {
        data_matrix = Matrix::Matrix(GEMLI_items[['gene_expression']])
    } else if (class(GEMLI_items)=='GEMLI') {
        data_matrix = GEMLI_items@gene_expression
    } else {
        stop('Object GEMLI_items should be either of class list or GEMLI')
    }

    cat('Define marker genes...')
    marker_genes = potential_markers(data_matrix)
    cat('OK\n')

    #function to apply in parallel
    myfun <- function(idx, seed) {
        set.seed(seed)
        marker_genes_sample = sample(marker_genes, round(length(marker_genes) * sample_size, 0))
        cell_clusters <- quantify_clusters_iterative(data_matrix, marker_genes_sample, N=2)
        clustersize_dict = table(paste0(
                                unlist(lapply(1:ncol(cell_clusters), function(i) rep(i, nrow(cell_clusters)))), 
                                '_', as.numeric(cell_clusters)
                                ))
        smallest_clusters = names(clustersize_dict)[clustersize_dict %in% desired_cluster_size]
        smallest_clusters = smallest_clusters[!grepl('_NA$', smallest_clusters)]
        best_prediction = matrix(FALSE, nrow=ncol(data_matrix), ncol=ncol(data_matrix))
        rownames(best_prediction) = colnames(data_matrix)
        colnames(best_prediction) = colnames(data_matrix)
        for (cluster in smallest_clusters) {
            col <- as.numeric(strsplit(cluster, '_')[[1]][[1]])
            val <- as.numeric(strsplit(cluster, '_')[[1]][[2]])
            cells_in_cluster = na.omit(rownames(best_prediction)[cell_clusters[, col] == val])
            best_prediction[cells_in_cluster, cells_in_cluster] = TRUE
        }
        diag(best_prediction) = FALSE
        best_prediction
    }

    #define number of cpus
    cat('Define cell clusters...')
    if (is.null(workers)) {
        workers <- future::availableCores() - 1
    }

    set.seed(42) #for reproducibility
    if (.Platform$OS.type == "unix") {
        results_list <- parallel::mclapply(1:repetitions, function(x) myfun(x, 42 + x), mc.cores = workers)
    } else {
        options(future.globals.maxSize = 50 * 1024^3)
        future::plan(callr, workers = workers)
        results_list <- future.apply::future_lapply(1:repetitions, function(x) myfun(x, 42 + x), future.seed = TRUE)
    }
    #myfun(1, 41 + 1)
    cat('OK\n')

    #combine results
    cat('Combine results...')
    results = matrix(0, nrow=ncol(data_matrix), ncol=ncol(data_matrix))
    rownames(results) = colnames(data_matrix)
    colnames(results) = colnames(data_matrix)
    for (mat in results_list) {
        results <- results + mat
    }
    cat('OK\n')

    #store results
    if (class(GEMLI_items) == 'list') {
        GEMLI_items[["prediction"]] = results
    } else if (class(GEMLI_items) == 'GEMLI') {
        GEMLI_items <- addPrediction(GEMLI_items, results)
    }

    return(GEMLI_items)
}
