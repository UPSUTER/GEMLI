calculate_correlations <- function(data, block_size = 500) {
    if (!inherits(data, "sparseMatrix")) {
        stop("The input data must be a sparse matrix.")
    }

    n <- ncol(data)
    similarity_matrix <- matrix(0, nrow = n, ncol = n)

    # Process the matrix in blocks of columns
    for (i in seq(1, n, by = block_size)) {
        #end of the current block
        end_i <- min(i + block_size - 1, n)
        data_block <- data[, i:end_i]

        #compute column norms
        data_block_t <- Matrix::t(data_block)
        col_norms_block <- sqrt(Matrix::colSums(data_block_t ^ 2))
        col_norms_block[col_norms_block == 0] <- 1

        #normalize
        normalized_block <- data_block_t %*% Matrix::Diagonal(x = 1 / col_norms_block)
        #normalized_block <- data_block_t Matrix::%*% Matrix::Diagonal(x = 1 / col_norms_block)
        #library(Matrix)
        #normalized_block <- Matrix::`%*%`(data_block_t, Diagonal(x = 1 / col_norms_block))

        #cross-product for the current block
        block_similarity <- as.matrix(tcrossprod(normalized_block))

        #store the result
        similarity_matrix[i:end_i, i:end_i] <- block_similarity

        #compute cross-products between the current block and all previous blocks
        if (i > 1) {  #ensure there is a previous block to process
            for (j in seq(1, i - 1, by = block_size)) {
                end_j <- min(j + block_size - 1, n)
                previous_block <- data[, j:end_j]

                previous_block_t <- Matrix::t(previous_block)
                col_norms_prev <- sqrt(Matrix::colSums(previous_block_t ^ 2))
                col_norms_prev[col_norms_prev == 0] <- 1
                normalized_previous_block <- previous_block_t %*% Diagonal(x = 1 / col_norms_prev)

                inter_block_similarity <- as.matrix(normalized_block %*% Matrix::t(normalized_previous_block))

                #store the result
                similarity_matrix[i:end_i, j:end_j] <- inter_block_similarity
                similarity_matrix[j:end_j, i:end_i] <- t(inter_block_similarity)
            }
        }
    }

    diag(similarity_matrix) <- 0
    rownames(similarity_matrix) <- colnames(similarity_matrix) <- colnames(data)

    return(similarity_matrix)
}
